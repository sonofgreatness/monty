push 1
push 2
push 3
pall
rotr
pall
