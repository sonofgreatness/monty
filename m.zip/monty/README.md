0x19. C - Stacks, Queues - LIFO, FIFO
